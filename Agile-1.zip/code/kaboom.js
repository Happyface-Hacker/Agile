import kaboom from "kaboom";

let width = ((window.innerWidth) % 2 === 0 ? (window.innerWidth) : (window.innerWidth) - 1);
let height = ((window.innerHeight) % 2 === 0 ? (window.innerHeight) : (window.innerHeight) - 1);

let ratio = Math.max(0.7, Math.min(1, window.innerWidth/1400));

const k = kaboom({
    width, height,
    // width: width/ratio,
    // height: height/ratio,
    // scale: ratio,
    touchToMouse: true,
    debug: location.hostname === 'localhost' ? true : false,
    background: [11, 11, 11],
})

window.k = k;
k.debug.inspect = false;

k.onLoad(() => {
    document.querySelector('canvas').focus();
})

k.loadFont("Staatliches", "Staatliches_font2bitmap.png", 30, 50, {
    filter: 'linear',
    chars: " !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"
})

k.loadSprite('gradient', './sprites/gradient.png')
k.loadSprite('line-v', './sprites/line-v.png')
k.loadSprite('line-h', './sprites/line-h.png')
k.loadSprite('icons', './sprites/sheet_white2x.png', {
    sliceX: 10,
    sliceY: 20,
})

k.loadSound('music1', `./sounds/music1.mp3`) // https://freesound.org/people/frankum/sounds/346193/
k.loadSound('pop', `./sounds/pop.wav`)
k.loadSound('hurt', `./sounds/hurt.wav`)

export default k