import k from '../kaboom';
import gameState from "../state";
import {w} from "../helpers";
import {currentTheme} from "../themes";
import game from "../scenes/game";

export const addBackground = () => {
    // Draw main background
    gameState.bg = k.add([
        'bg',
        k.rect(k.width(), k.height()),
        k.pos(0, 0),
        k.fixed(),
        {
            defaultColor: k.rgb(21, 21, 32),
            // defaultColor: k.rgb(darkenRGB(currentTheme().primaryColor, 0.2)),
            waveChange: 3,
            add() {
                this.color = this.defaultColor;
            },
            update() {
                // this.defaultColor = k.rgb(darkenRGB(currentTheme().primaryColor, 0.2));
            },
            draw() {
                let posPerc = 1 - (((gameState.camPosY + 50) - k.height() / 2) / k.height());
                this.color = k.rgb(
                    w((this.defaultColor.r * posPerc) - this.waveChange, (this.defaultColor.r * posPerc) + this.waveChange, 1),
                    w((this.defaultColor.g * posPerc) - this.waveChange, (this.defaultColor.g * posPerc) + this.waveChange, 1.5),
                    w((this.defaultColor.b * posPerc) - this.waveChange, (this.defaultColor.b * posPerc) + this.waveChange, 2)
                );
            }
        }
    ]);

    // Draw bottom gradient
    k.add([
        'gradient',
        k.sprite('gradient', {width: k.width(), height: 331, filed: true}),
        k.pos(0, k.height() - 300),
        k.color(k.rgb(...currentTheme().primaryColor)),
        k.fixed(),
        k.opacity(0.8),
        {
            update() {
                this.color = k.rgb(...currentTheme().primaryColor);
            },
            draw() {
                this.opacity = 0.8 - ((gameState.camPosY + 300) - k.height() / 2) / k.height();
            }
        }
    ]);

    // Best distance line
    const bestScore = Math.floor(gameState.bestScore);
    if (bestScore > 0) {
        const smallScreen = window.innerWidth < 576;
        const blockSize = 50 * gameState.scale;
        const startingOffset = blockSize * 2;
        k.add([
            k.sprite('line-h', {width: k.width(), height: 1, tiled: true}),
            k.pos(0, 0),
            k.color(255, 255, 255),
            // k.opacity(0.2),
            k.area(),
            k.outview({hide: true}),
            {
                distance: bestScore,
                text: 'Personal best score',
                textPos: k.vec2(Math.round(k.width()/2-gameState.width/2 + 10), smallScreen || true ? -15 : -25),
                update() {
                    this.pos.y = Math.round((gameState.playerLevel * blockSize - this.distance * blockSize) + k.height() - startingOffset);
                    this.color = Math.floor(gameState.playerLevel) > bestScore ? k.rgb(...currentTheme().primaryColor) : k.rgb(255, 255, 255);
                },
                draw(){
                    k.drawText({
                        text: this.text,
                        size: smallScreen || true ? 8 : 16,
                        font: "sink",
                        // opacity: 0.5,
                        pos: this.textPos,
                        color: this.color,
                    })
                }
            }
        ]);
    }

    // Borders
    if (window.innerWidth !== gameState.width) {
        k.add([
            'border',
            k.sprite('line-v', {width: 1, height: k.height(), tiled: true}),
            k.pos(k.width() / 2 - gameState.width / 2, 0),
            k.color(k.rgb(...currentTheme().primaryColor)),
            k.fixed(),
            k.opacity(0.5),
            {
                update() {
                    this.color = k.rgb(...currentTheme().primaryColor);
                }
            }
        ]);
        k.add([
            'border',
            k.sprite('line-v', {width: 1, height: k.height(), tiled: true}),
            k.pos(k.width() / 2 + gameState.width / 2, 0),
            k.color(k.rgb(...currentTheme().primaryColor)),
            k.fixed(),
            k.opacity(0.5),
            {
                update() {
                    this.color = k.rgb(...currentTheme().primaryColor);
                }
            }
        ]);
    }

    // Draw circles
    k.loop(1, () => {
        if (gameState.gameOver) {
            return;
        }

        k.add([
            k.circle(k.choose([100, 125, 150, 175, 200])),
            k.pos(k.randi(k.width()), k.randi(k.height())),
            k.opacity(0),
            k.color(k.rgb(...currentTheme().primaryColor)),
            k.move(k.randi(360), k.choose([40, 50, 60])),
            k.lifespan(10, {fade: 0.5}),
            k.fixed(),
            {
                removing: false,
                update() {
                    this.color = k.rgb(...currentTheme().primaryColor);

                    if (!this.removing) {
                        this.opacity = Math.min(0.1, this.opacity + 0.0005);
                    } else {
                        this.opacity = Math.max(0, this.opacity - 0.0005);
                    }

                    if (this.opacity === 0.1) {
                        this.removing = true;
                    }

                    if (this.removing && this.opacity === 0) {
                        this?.destroy();
                    }
                }
            }
        ]);
    })
}