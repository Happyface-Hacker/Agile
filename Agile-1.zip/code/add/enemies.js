import k from '../kaboom';
import gameState from "../state";
import destroyAnimation from "../components/destroyAnimation";
import {currentTheme} from "../themes";
import {darkenRGB} from "../helpers";

export const addEnemies = ({player}) => {
    const number = Math.floor(k.height() / 50*gameState.reversedScale);

    let widthHalf = gameState.width/2;
    let center = k.width()/2;

    for (
        let i = Math.floor(gameState.playerLevel);
         i < number + Math.floor(gameState.playerLevel);
         i++
    ) {
        if (i > gameState.enemyCreated) {
            k.add([
                'enemy',
                'enemy_' + Math.floor(gameState.playerLevel),
                k.rect(48, 48, {radius: 5}),
                k.pos(k.randi(center-widthHalf+48, center+widthHalf-48), k.height() - 75*gameState.scale - 50*gameState.scale - (i*gameState.scale) * 50),
                k.area({width: 35, height: 35}),
                k.origin('center'),
                k.outview({hide: true, pause: false}),
                k.rotate(0),
                k.scale(gameState.scale),
                destroyAnimation(),
                {
                    speed: k.choose([1,2,3,4,5]) * (1+((gameState.playerLevel/100)*0.1)),
                    direction: k.choose([-1, 1]),
                    startY: k.height() - 75*gameState.scale - 50*gameState.scale - (i*gameState.scale) * 50,
                    collided: false,
                    scaleVal: 0,
                    type: null,
                    add() {
                        if ((i % 100) === 0) {
                            this.type = 'health';
                            this.use(k.color(k.rgb(255, 255, 255)));
                        } else if ((i % 50) === 0) {
                            this.type = 'random';
                            this.use(k.color(k.rgb(246, 216, 224)));
                        } else {
                            this.type = 'normal';
                            this.use(k.color(k.rgb(...currentTheme().primaryColor)));
                        }
                    },
                    draw() {
                        if (this.type === 'random') {
                            k.drawSprite({
                                sprite: "icons",
                                pos: vec2(1, 5),
                                width: 50,
                                origin: 'center',
                                frame: 62,
                                color: k.rgb(21, 21, 32),
                            })
                        }
                    },
                    collisionEffect() {
                        let effect = this.type;

                        if (effect === 'random') {
                            effect = k.choose([
                                'health',
                                'godmode', 'godmode', 'godmode',
                                'normal', 'normal',
                                'clear', 'clear', 'clear',
                            ]);
                        }

                        if (effect === 'health') {
                            player.health += 1;
                            k.play('pop');
                            k.add([
                                k.text('Health +1', {size: 16, font: 'sink'}),
                                k.pos(player.pos.x, player.pos.y),
                                k.origin('center'),
                                k.lifespan(0.5, {fade: 0.5}),
                                {
                                    update() {
                                        this.pos.y -= 5;
                                    }
                                }
                            ]);
                            this?.destroy();
                        } else if (effect === 'clear') {
                            k.play('hurt');
                            k.shake(10);
                            k.get('enemy').forEach(function (enemy) {
                                enemy.destroyAnimation();
                                enemy?.destroy();
                            });
                            this?.destroy();
                        } else if (effect === 'godmode') {
                            gameState.music.speed(1.5);
                            gameState.speed = 2;
                            player.opacity = 0.5;
                            player.godmode = true;
                            player.moveStep = 2;
                            this?.destroy();
                            k.wait(5, function () {
                                gameState.music.speed(1);
                                gameState.speed = 1;
                                player.opacity = 1;
                                player.moveStep = 1;
                                player.godmode = false;
                            });
                        } else if (effect === 'normal' && !player.protection) {
                            player.hurt(player.pos.x < this.pos.x ? 'right' : 'left');
                            k.shake(10);
                            if (player.health <= 0) {
                                player.destroyAnimation();
                                player?.destroy();
                                gameState.setGameOver();
                                return;
                            } else {
                                this.destroyAnimation();
                                this?.destroy();
                            }
                        }
                    },
                    lastRotate: 0,
                    update() {
                        if(this.type === 'normal') {
                            this.color = k.rgb(...currentTheme().primaryColor);
                        }

                        if (!this.collided && this.isColliding(player)) {
                            this.collisionEffect();
                            this.collided = true;
                        }

                        this.pos.y = this.startY + (gameState.playerLevel*gameState.scale) * 50;
                        this.pos.x += (this.speed * gameState.speed * (gameState.started ? 1 : 0.5)) * this.direction;

                        if (this.pos.x-24 < center-widthHalf || this.pos.x+24 > center+widthHalf) {
                            this.direction *= -1;
                        }

                        if (this.pos.y - gameState.camPosY > k.height()) {
                            this?.destroy();
                        }
                    }
                }
            ]);
            gameState.enemyCreated = i;
        }
    }
}