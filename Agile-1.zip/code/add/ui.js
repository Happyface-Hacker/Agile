import k from '../kaboom';
import gameState from "../state";
import {currentTheme} from "../themes";
import {darkenRGB, isMobile} from "../helpers";

export const addUI = () => {
    let player = k.get('player')[0];
    k.onDraw(function () {
        const time = new Date().getTime();

        if (gameState.gameOver) {
            k.drawText({
                text: `[SCORE:${Math.floor(gameState.playerLevel)}].score
[${isMobile() ? 'TAP TO RESTART' : 'PRESS SPACE TO RESTART'}].info
[BEST SCORE:${gameState.bestScore}].best`,
                pos: k.vec2(k.width() / 2 + 10, k.height() / 2 - (import.meta.env.VITE_IS_REPLIT && !gameState.logged_in ? 100 : 30)),
                fixed: true,
                texFilter: 'linear',
                origin: 'center',
                font: 'Staatliches',
                letterSpacing: -6,
                lineSpacing: 10,
                scale: gameState.scale,
                width: window.innerWidth,
                styles: {
                    "score": {},
                    "info": (idx, ch) => ({
                        color: k.rgb(...darkenRGB(currentTheme().primaryColor, 1.5)),
                        scale: time % 2000 < 1500 ? 1 : 0.0001,
                    }),
                    "best": (idx, ch) => ({
                        scale: 0.8,
                    }),
                    "stats": (idx, ch) => ({
                        scale: 0.8,
                    }),
                }
            });

            if (import.meta.env.VITE_IS_REPLIT) {
                k.drawText({
                    text: `[           Rank:].chuj [${!gameState.logged_in ? 'Unauthorized' : (gameState.rank === 'loading' ? 'LOADING' : (gameState.rank + '/' + gameState.total))}].value 
[         Played:].chuj [${gameState.played} ${gameState.played > 1 ? 'times' : 'time'}].value`,
                    pos: k.vec2(k.width() / 2 - 190, k.height() / 2 + (gameState.logged_in ? 100 : 60)),
                    fixed: true,
                    texFilter: 'linear',
                    origin: 'left',
                    font: 'Staatliches',
                    letterSpacing: -5,
                    lineSpacing: 0,
                    size: 28,
                    width: window.innerWidth,
                    styles: {
                        "chuj": (idx, ch) => ({
                            color: k.rgb(...darkenRGB(currentTheme().primaryColor, 1.5)),
                        }),
                        "value": (idx, ch) => ({
                            color: k.rgb(255, 255, 255),
                        })
                    }
                });

                if (!gameState.logged_in && !k.get('login-button').length) {
                    k.add([
                        'login-button',
                        k.text('Login with Replit', {font: 'Staatliches'}),
                        k.area(),
                        k.scale(0.8),
                        k.origin('center'),
                        k.pos(k.width()/2, k.height()/2 + 110),
                        {
                            clicked: false,
                            update() {
                                if(gameState.logged_in) {
                                    this.destroy();
                                    return;
                                }
                                this.color = this.isHovering() ? k.rgb(180, 180, 180) : k.rgb(255, 255, 255);
                                if(!this.clicked && this.isClicked()){
                                    this.clicked = true;
                                    k.wait(0.1, () => {
                                        gameState.loginWithReplit();
                                    });
                                }
                            }
                        }
                    ]);
                }
            }
        } else {
            // Draw health bar
            for (let i = 0; i < player.health; i++) {
                k.drawRect({
                    width: 25,
                    height: 25,
                    pos: k.vec2(k.width() / 2 - gameState.width / 2 + 15 + (i * 35), 10),
                    color: WHITE,
                    radius: 3,
                    fixed: true,
                });
            }

            // Draw current score
            k.drawText({
                text: `${Math.floor(gameState.playerLevel)}`,
                size: 16,
                font: "sink",
                width: 600,
                texFilter: 'linear',
                pos: k.vec2(k.width() / 2, 15),
                color: rgb(255, 255, 255),
                fixed: true,
            })

            if (!gameState.started) {
                k.drawText({
                    text: `[${isMobile() ? 'GET AS HIGH\nAS YOU CAN' : 'GET AS HIGH AS YOU CAN'}].secondary
[${isMobile() ? 'TOUCH\nTO\nSTART ' : 'PRESS SPACE TO START'}].primary`,
                    pos: k.vec2(k.width() / 2 + 10, k.height() / 2),
                    fixed: true,
                    font: 'Staatliches',
                    texFilter: 'linear',
                    letterSpacing: -4,
                    width: window.innerWidth,
                    origin: 'center',
                    styles: {
                        "secondary": {
                            color: k.rgb(...darkenRGB(currentTheme().primaryColor, 1.5)),
                            scale: 0.6,
                        },
                        "primary": (idx, ch) => ({
                            scale: time % 2000 < 1500 ? 1 : 0.0001,
                        }),
                    }
                });
            }
        }
    });
}