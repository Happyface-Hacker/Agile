import k from '../kaboom';
import gameState from "../state";
import {round} from "../helpers";
import destroyAnimation from "../components/destroyAnimation";
import {addEnemies} from "./enemies";

export const addPlayer = () => {
    return k.add([
        'player',
        k.rect(50, 50, {radius: 5}),
        k.pos(k.width() / 2, k.height() - 75 * gameState.scale),
        k.area({width: 35, height: 35}),
        k.color(k.rgb(255, 255, 255)),
        k.origin('center'),
        k.z(1),
        k.rotate(0),
        k.scale(gameState.scale),
        destroyAnimation(),
        {
            health: 3,
            lastRotate: 0,
            rotationTime: 0.1,
            defaultHeight: 50,
            targetHeight: 50,
            godmode: false,
            protection: false,
            moveStep: 1,
            currMoveStep: 0,
            hurt(side = 'left') {
                if (this.godmode) return;

                this.health -= 1;
                k.play('hurt');
                if (side === 'left') {
                    this.lastRotate += 180;
                } else {
                    this.lastRotate -= 180;
                }
                gameState.bg.color = k.rgb(255, 0, 0);
                gameState.resetOneMoveDistance();

                if(this.health > 0) {
                    this.protection = true;
                    k.wait(2).then(() => {
                       this.protection = false;
                    });
                }
            },
            moveToUp() {
                gameState.camPosY += (this.currMoveStep * 50* gameState.scale) * 0.15;
                gameState.playerLevel += (this.currMoveStep) * 0.15;
                gameState.oneTimeDistance += (this.currMoveStep) * 0.15;
                addEnemies({player: this});
            },
            update() {
                if(this.protection) {
                    this.opacity = 0.5;
                } else {
                    this.opacity = 1;
                }

                this.height = round(k.lerp(this.height, this.targetHeight, 0.2), 2);

                this.angle = k.lerp(this.angle, this.lastRotate, this.rotationTime);
                if (this.angle === this.lastRotate) {
                    this.rotationTime = 0.1;
                }

                if (gameState.gameOver) return;

                if ((k.time() - gameState.sceneStartTime > 0.1) && (k.isKeyDown('space') || k.isMouseDown('left'))) {
                    if(!gameState.music){
                        try {
                            gameState.music = k.play('music1', {loop: true});
                        } catch (e) {
                            alert(e);
                            gameState.music = null;
                        }
                    }
                    if (!gameState.started) {
                        gameState.started = true;
                        gameState.startedTime = k.time();
                        gameState.time = 0;
                    }
                    this.currMoveStep = k.lerp(this.currMoveStep, this.moveStep, 0.2 * gameState.scale);
                    this.moveToUp();
                } else {
                    this.currMoveStep = 0;
                    gameState.resetOneMoveDistance();
                }

                if (
                    (gameState.camPosY + 50 * gameState.scale) - k.height() / 2 < 0
                ) {
                    this.hurt();
                    this.destroyAnimation();
                    this?.destroy();
                    gameState.setGameOver();
                }
            }
        }
    ]);
}