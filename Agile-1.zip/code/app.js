import k from './kaboom';
import game from "./scenes/game";

k.scene('game', game);

k.go('game');