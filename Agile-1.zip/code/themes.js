import GameState from "./state";

const themeFreqChange = 100;

const themes = [
    {
        primaryColor: [200, 50, 50],
    },
    {
        primaryColor: [138, 201, 38],
    },
    {
        primaryColor: [25, 130, 196],
    },
    {
        primaryColor: [255, 202, 58],
    },
    {
        primaryColor: [0, 95, 115],
    }
];

export default themes;

export const currentTheme = () => {
    return themes[Math.floor(GameState.playerLevel / themeFreqChange) % themes.length];
}