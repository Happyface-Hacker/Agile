import k from "./kaboom";
import {jsonp, storeScore} from "./api";

export default class GameState {
    static reset() {
        let maxWidth = 1000;
        this.width = Math.min(maxWidth, window.innerWidth);
        this.scale = 1;
        this.reversedScale = 1;
        if (this.width < maxWidth) {
            this.scale = Math.max(0.6, this.width / maxWidth);
            this.reversedScale = 1 / this.scale;
        }
        this.bg = null;
        this.music?.stop();
        this.music = null;
        this.playerLevel = 0;
        this.enemyCreated = 0;
        this.camPosY = k.camPos().y;
        this.started = false;
        this.startedTime = 0;
        this.gameOver = false;
        this.gameOverTime = 0;
        this.sceneStartTime = k.time();
        this.speed = (k.width() / maxWidth);
        this.time = 0;
        this.bestScore = k.getData('synthone_bestScore') || 0;
        this.oneTimeDistance = 0;
        this.longestMove = 0;
        this.played = k.getData('synthone_played') || 0;
        this.rank = 'loading';
        this.total = 'loading';
        this.logged_in = k.getData('synthone_logged') || 0;
    }

    static setGameOver() {
        this.gameOver = true;
        this.gameOverTime = k.time();

        let loop = k.loop(0.1, () => {
            this.music.volume(this.speed -= 0.02)
            this.music.speed(this.speed -= 0.02)
            if (this.speed <= 0) {
                loop();
            }
        })

        if (!this.bestScore || this.bestScore < this.playerLevel) {
            this.bestScore = Math.floor(this.playerLevel);
            k.setData('synthone_bestScore', this.bestScore);
        }

        if (import.meta.env.VITE_IS_REPLIT && this.logged_in) {
            storeScore(this.playerLevel, this.bestScore).then(({data}) => {
                if (data.logged_in) {
                    this.rank = data.rank;
                    this.total = data.total;
                } else {
                    this.logged_in = false;
                    k.setData('synthone_logged', 0);
                }
            })
        }

        k.setData('synthone_played', this.played + 1);
    }

    static resetOneMoveDistance() {
        if (this.oneTimeDistance > this.longestMove) {
            this.longestMove = this.oneTimeDistance;
        }
        this.oneTimeDistance = 0;
    }

    static loginWithReplit() {
        let that = this;

        window.addEventListener('focus', loginFinalization);

        window.open("https://agile-backend.darekccc.repl.co/", '_blank').focus();

        function loginFinalization() {
            jsonp('get_auth').then(({data}) => {
                if (data.logged_in) {
                    that.logged_in = true;
                    k.setData('synthone_logged', 1);

                    storeScore(that.playerLevel, that.bestScore).then(({data}) => {
                        that.rank = data.rank;
                        that.total = data.total;
                    })
                }
            });

            window.removeEventListener('focus', loginFinalization);
        }
    }
}