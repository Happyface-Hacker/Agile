import axios from "axios";
import _jsonp from "jsonp";

axios.defaults.headers.common['Content-Type'] = 'application/x-www-form-urlencoded'
axios.defaults.baseURL = 'https://agile-backend.darekccc.repl.co/';

export const get = (action, data) => {
    let query = '';
    for (let key in data) {
        query += `&${key}=${data[key]}`;
    }

    return axios.get(`api.php?action=${action}${query}`);
}

export const post = (action, data) => {
    return axios.post(`api.php?action=${action}`, data, {
        mode: 'no-cors',
        withCredentials: false,
    })
}

export const jsonp = (action, data = {}) => {
    let query = '';
    for (let key in data) {
        query += `&${key}=${data[key]}`;
    }

    return new Promise((resolve, reject) => {
        _jsonp(axios.defaults.baseURL + 'api.php?action=' + action + query, null, function (err, data) {
            if (err) {
                reject({err})
            } else {
                resolve({data});
            }
        });
    });
}

export const ping = () => {
    return jsonp('ping');
}

export const storeScore = (score, bestScore) => {
    return jsonp('store_score', {score, best_score: bestScore});
}