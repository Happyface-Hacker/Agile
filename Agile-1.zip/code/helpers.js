import k from "./kaboom";

let tt = (n = 1) => k.time() * n

export const w = (a, b, n) => k.wave(a, b, tt(n))

export const round = (n, p = 1) => Math.ceil(n * p) / p;

export const darkenRGB = (rgb, n = 0.1) => {
    let newRGB = [];
    newRGB[0] = rgb[0] * n;
    newRGB[1] = rgb[1] * n;
    newRGB[2] = rgb[2] * n;
    return newRGB;
}

export const isMobile = () => {
    return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
}