import k from "../kaboom";
import gameState from '../state';
import {addBackground} from "../add/background";
import {addPlayer} from "../add/player";
import {addUI} from "../add/ui";
import {addEnemies} from "../add/enemies";
import {ping} from "../api";

export default async function () {
    if (import.meta.env.VITE_IS_REPLIT) {
        console.log('PING');
        ping().then(({data}) => {
            console.log(data?.message === 'pong' ? 'PONG' : 'Ping failed');

            if (data?.message === 'pong' && !data.logged_in) {
                gameState.logged_in = false;
                k.setData('synthone_logged', 0);
            }
        });
    }

    gameState.reset();

    const player = addPlayer();

    addBackground();

    addEnemies({player});

    mainGameLoop({player});

    addUI();

    k.onKeyPress('r', () => {
        k.go('game');
    });

    k.onKeyPress('p', () => {
        gameState.loginWithReplit();
    });
}

function mainGameLoop({player}) {
    let startCamPosY = k.camPos().y;
    k.onUpdate(() => {
        if (gameState.gameOver && k.time() - gameState.gameOverTime > 1) {
            if (k.isKeyPressed('space') || k.isMousePressed('left')) {
                const loginBtn = k.get('login-button');
                if(!(loginBtn.length && loginBtn[0].isHovering())){
                  k.go('game');
                }
            }
        }

        if (gameState.gameOver) return;

        if (gameState.started) {
            gameState.time += k.dt(); // update game time
        }

        if (gameState.time > 9) {
            gameState.bg.waveChange = 10;
        }

        // Update camera position
        if (gameState.started) {
            let value = Math.pow((gameState.camPosY / startCamPosY), 2 * player.moveStep);
            gameState.camPosY -= value * gameState.scale;
        }

        k.camPos(k.width() / 2, gameState.camPosY);
    });
}