import k from '../kaboom';

export default () => {
    return {
        destroyAnimation() {
            k.add([
                k.rect(50, 50, {radius: 5}),
                k.pos(this.pos.x, this.pos.y),
                k.color(k.rgb(this.color.r, this.color.g, this.color.b)),
                k.origin('center'),
                k.lifespan(0.5, {fade: 0.5}),
                {
                    scaleVal: 1,
                    update() {
                        this.scale = (this.scaleVal += 0.1);
                    }
                }
            ]);
        }
    }
};
