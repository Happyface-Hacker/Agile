import {defineConfig} from "vite";

const config = {
    base: '',
    server: {
        host: '0.0.0.0',
        hmr: false,
    },
    build: {emptyOutDir: false}
};

export default defineConfig(({command, mode, ssrBuild}) => {
    let actAsReplit = false;
    let isReplit = process.env.REPL_OWNER || actAsReplit || '';
    process.env.VITE_IS_REPLIT = isReplit;
    if (isReplit && !actAsReplit) {
        config.server.port = 443;
    }

    return config;
})